package main

import "gometr/internal/app"

func main() {
	app.Start()
}
